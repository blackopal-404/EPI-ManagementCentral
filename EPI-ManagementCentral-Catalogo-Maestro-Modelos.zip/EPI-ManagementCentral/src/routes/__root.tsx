import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  useRouterState,
  Link,
  Navigate,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { useEffect, type ReactNode } from "react";

import appCss from "../styles.css?url";
import { reportRuntimeError } from "../lib/error-reporting";
import { AppShell } from "@/components/layout/AppShell";
import { AdminShell } from "@/components/layout/AdminShell";
import { Toaster } from "@/components/ui/sonner";
import { AuthProvider, useAuth } from "@/lib/auth";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">Page not found</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Go home
          </Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: unknown; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  useEffect(() => {
    reportRuntimeError(error instanceof Error ? error : new Error(String(error)), { boundary: "tanstack_root_error_component" });
  }, [error]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold tracking-tight text-foreground">
          This page didn't load
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Something went wrong on our end. You can try refreshing or head back home.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button
            onClick={() => {
              router.invalidate();
              reset();
            }}
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Try again
          </button>
          <a
            href="/"
            className="inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent"
          >
            Go home
          </a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "EPIControl — Gestión y trazabilidad de EPP/EPI" },
      {
        name: "description",
        content:
          "Sistema central para controlar equipos de protección personal e industrial: catálogo técnico, identificación por código, inventario e inspecciones.",
      },
      { property: "og:title", content: "EPIControl — Gestión y trazabilidad de EPP/EPI" },
      {
        property: "og:description",
        content:
          "Catálogo técnico, equipos individuales, inspecciones e inventario de equipos de protección.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Archivo:wght@500;600;700;800&family=Barlow:wght@400;500;600;700&family=IBM+Plex+Mono:wght@400;500&display=swap",
      },
      { rel: "icon", href: "/favicon.ico", type: "image/x-icon" },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="es">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <AuthenticatedApp />
      </AuthProvider>
    </QueryClientProvider>
  );
}

function AuthenticatedApp() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const isAdmin = pathname.startsWith("/admin");
  const adminOnlyPaths = ["/reportes", "/cotizaciones", "/inventario", "/productos", "/categorias"];
  const isAdminOnly = isAdmin || adminOnlyPaths.some((path) => pathname === path || pathname.startsWith(`${path}/`));
  const { user, ready } = useAuth();

  if (pathname === "/login") return <Outlet />;
  if (!ready) return <div className="grid min-h-screen place-items-center bg-background text-sm text-muted-foreground">Cargando sesión…</div>;
  if (!user) return <Navigate to="/login" replace />;
  // Magna y administración pueden entrar a todo. Los demás usuarios solo acceden a rutas
  // habilitadas en los permisos de su categoría; el backend vuelve a validar cada operación.
  const fullAccess = user.role === "magna" || user.role === "administrador";
  const routePermission: Record<string,string> = {
    "/admin/ventas":"sales", "/admin/bodega":"warehouse", "/admin/plan-compras":"purchases",
    "/admin/usuarios":"users", "/admin/configuracion":"settings", "/admin/reportes":"reports",
    "/admin/cotizador":"quotes", "/admin/inventario":"inventory", "/admin/productos":"products",
    "/admin/categorias":"categories", "/admin/empresas":"companies", "/admin/equipos":"equipment",
    "/admin/inspecciones":"inspections", "/admin/reporte-inspecciones":"inspection_reports",
    "/reportes":"reports", "/cotizaciones":"quotes", "/inventario":"equipment", "/productos":"products", "/categorias":"categories",
  };
  const requiredPermission = routePermission[pathname] ?? (pathname === "/admin" || pathname === "/admin/" ? "dashboard" : undefined);
  const hasDashboardAccess = (user.permissions ?? []).some(permission => permission !== "scanner");
  const productAreaPaths = ["/admin/productos", "/admin/bodega", "/admin/categorias"];
  const hasProductAreaAccess = pathname === "/admin/productos"
    && (user.permissions ?? []).some(permission => ["products", "warehouse", "categories"].includes(permission));
  const hasRouteAccess = fullAccess || hasProductAreaAccess || (!!requiredPermission && (user.permissions ?? []).includes(requiredPermission)) || (requiredPermission === "dashboard" && hasDashboardAccess);
  if (isAdminOnly && !hasRouteAccess) return <Navigate to="/" replace />;

  return (
    <>
      {isAdmin ? (
        <AdminShell>
          <Outlet />
        </AdminShell>
      ) : (
        <AppShell>
          <Outlet />
        </AppShell>
      )}
      <Toaster />
    </>
  );
}

